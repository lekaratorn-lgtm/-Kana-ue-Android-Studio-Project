package org.kaanu.keyboard

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import android.graphics.Typeface

class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
  val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,32,24,24) }
  root.addView(TextView(this).apply { text="Kàànu — Khana Keyboard"; textSize=24f; setTypeface(null,Typeface.BOLD) })
  root.addView(TextView(this).apply { text="Offline Khana word suggestions and tone-marked characters"; textSize=14f })
  root.addView(Button(this).apply { text="1. Enable Kàànu keyboard"; setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) } })
  root.addView(Button(this).apply { text="2. Choose Kàànu as your keyboard"; setOnClickListener { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() } })
  root.addView(TextView(this).apply { text="After enabling it in Android Settings, select Kàànu from the keyboard picker. The keyboard works offline. It only sends text to the app where you type; this project contains no network code."; textSize=14f })
  setContentView(root)
 }
}
